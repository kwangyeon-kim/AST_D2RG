==============================================================================
Development of Data-Driven Conflict Resolution Generator for En-Route Airspace
==============================================================================
		<<Kwangyeon Kim, Raj Deshmukh, Inseok Hwang>>

Sample files:

>>> Real flight data
> manAC_1a.mat and manAC_1b.mat: Altitudes (y) of maneuvering aircraft in cruise phase with step altitude maneuvers, against epoch time (x), as recorded in real flight data

>>> Horizontal maneuvers
> DT1.mat and DT2.mat: Direct-to resolution type
> PS1.mat and PS2.mat: Path stretch resolution type
> RO1.mat and RO2.mat: Route offset resolution type
	Positions of maneuvering aircaft (green) and another conflicting aircraft (red), with maneuvering aircraft's flight plan (blue asterisks). The position of the maneuvering aircraft at time of potential loss of separation is marked with a black square.
> Sample MATLAB code to obtain positional plot:
	plot(manAC_latitude,manAC_longitude,'g')
	hold on
	plot(otherAC_latitude,otherAC_longitude,'r')
	plot(manAC_WP(:,2),manAC_WP(:,1),'b*')
	plot(manAC_latitude(manAC_time==manAC_timeofFL),manAC_longitude(manAC_time==manAC_timeofFL),'ks')

>>> Vertical maneuvers
> TAC1.mat and TAC2.mat: Temporary altitude climb resolution type
> SAC1.mat and SAC2.mat: Step altitude resolution type
> TAD1.mat and TAD2.mat: Temporary altitude descent resolution type
	Positions of maneuvering aircaft (green) and another conflicting aircraft (red). The altitude of the maneuvering aircraft at time of potential loss of separation is marked with a black square.
> Sample MATLAB code to obtain altitude plot:
	plot(manAC_time,manAC_altitude,'g')
	hold on
	plot(otherAC_time,otherAC_altitude,'r')
	plot(manAC_timeofFL,manAC_altitude(manAC_time==manAC_timeofFL),'ks')

>>> Speed maneuvers
> TCS1.mat and TCS2.mat: Temporary change in speed resolution type
> PCS1.mat and PCS2.mat: Permanent change in speed resolution type
	Airspeeds of maneuvering aircaft are in green. The airspeed of the maneuvering aircraft at time of potential loss of separation is marked with a black square.
> Sample MATLAB code to obtain speed plot:
	plot(manAC_time,manAC_spd,'g')
	hold on
	plot(manAC_timeofFL,manAC_spd(manAC_time==manAC_timeofFL),'ks')